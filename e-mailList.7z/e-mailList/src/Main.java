/*
TODO: Написать программу, в которой будет храниться перечень e-mail-ов.
 E-mail’ы  можно добавлять через консоль командой ADD и печатать весь список командой LIST.
 *Проверять корректность вводимых e-mail’ов и в случае необходимости печатать сообщение об ошибке.

Pattern p = Pattern.compile("\\b[A-Za-z0-9._%+-]+0[A-Za-z0-9.-]+\\.[A-Za-z](2,4)\\b");
            Matcher m = p.matcher(text);
            while (m.find()) {
                continue;
            }
 */
import java.util.HashSet;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main
{
    public static void main(String[] args)
    {
        String command;
        System.out.println("Вы можете посмотреть список существующих e-mail командой LIST \n так же, можете добавить новый e-mail командой ADD ");
        Scanner scanner = new Scanner(System.in);
        while (true){
            command = scanner.nextLine();
            String[] parts = command.split(" ", 2);
            String action = parts[0];
            String text = null;
            if(parts.length > 1)
            {
                text = parts[1];
            }
            HashSet<String> eMail = new HashSet<>();
            eMail.add("qwerty@mail.ru");
            eMail.add("stan@gmail.com");
            eMail.add("zzz@gmail.com");
            eMail.add("cat@bk.ru");
            eMail.add("fiveth@gmail.com");
                if (action.equals("ADD")) {
                    eMail.add(text);
                    for (String email : eMail) {
                        System.out.println(email);
                    }
                } else if (action.equals("LIST")) {
                    for (String email : eMail) {
                        System.out.println(email);
                    }
                }
                else {
                    System.out.println("Введите команду корректно");
                }

            System.out.println("email введен некорркетно, попробуйте ещё раз");
        }
    }
}
